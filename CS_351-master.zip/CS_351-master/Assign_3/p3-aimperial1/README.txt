Name: Andres Imperial
Email: andres.imperial@csu.fullerton.edu
Language: c++


How to execute:
	Compile the program using the Makefile.(typing "make")
	Then start executing the program by using:
	./multihash <TARGET FILE>
	Use the name of the file you wish to get hash values for.

Extra Credit: 
	Not Implemented

Notes:
	N/A
